"use client"

import { motion } from "framer-motion"
import { Download, ArrowLeft, Mail, MapPin, Linkedin } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function CVPage() {
  const handleDownload = () => {
    const link = document.createElement("a")
    link.href = "https://drive.google.com/file/d/1qVqoTP2oHKOMnKMzqGqUSTOSw2awMTHV/view?usp=sharing"
    link.target = "_blank" // Open in a new tab
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <div className="min-h-screen bg-white dark:bg-black text-black dark:text-white">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-white/80 dark:bg-black/80 backdrop-blur-md border-b border-gray-200 dark:border-gray-800">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <Button asChild variant="ghost" className="text-gray-400 hover:text-white">
            <Link href="/">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Portfolio
            </Link>
          </Button>
          <Button onClick={handleDownload} className="bg-purple-600 hover:bg-purple-700 text-white">
            <Download className="w-4 h-4 mr-2" />
            Download CV
          </Button>
        </div>
      </div>

      {/* CV Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="bg-white text-black rounded-lg shadow-2xl overflow-hidden"
        >
          {/* CV Preview */}
          <div className="p-8">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold mb-4">CV Preview</h1>
              <p className="text-gray-600 mb-6">
                Click the download button above to get the full PDF version of my CV.
              </p>

              {/* PDF Embed */}
              <div className="w-full h-96 border border-gray-300 rounded-lg overflow-hidden">
                <iframe
                  src="https://drive.google.com/file/d/1qVqoTP2oHKOMnKMzqGqUSTOSw2awMTHV/preview"
                  className="w-full h-full"
                  title="Dhir Shah CV Preview"
                />
              </div>

              <div className="mt-6">
                <Button onClick={handleDownload} className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3">
                  <Download className="w-5 h-5 mr-2" />
                  Download Full CV (PDF)
                </Button>
              </div>
            </div>
          </div>

          {/* Header Section */}
          <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-8">
            <div className="text-center">
              <h1 className="text-4xl font-bold mb-2">Dhir Shah</h1>
              <p className="text-xl mb-4">
                Undergraduate Student Pursuing Economics and Mathematics, with a Minor in Statistics
              </p>
              <div className="flex flex-wrap justify-center gap-4 text-sm">
                <div className="flex items-center">
                  <Mail className="w-4 h-4 mr-1" />
                  dhir.shah@mail.utoronto.ca
                </div>
                <div className="flex items-center">
                  <MapPin className="w-4 h-4 mr-1" />
                  Toronto, Ontario, Canada
                </div>
                <div className="flex items-center">
                  <Linkedin className="w-4 h-4 mr-1" />
                  linkedin.com/in/itsdhir
                </div>
              </div>
            </div>
          </div>

          <div className="p-8 space-y-8">
            {/* Professional Summary */}
            <section>
              <h2 className="text-2xl font-bold mb-4 text-gray-800 border-b-2 border-purple-600 pb-2">
                Professional Summary
              </h2>
              <p className="text-gray-700 leading-relaxed">
                Dedicated undergraduate student with a strong foundation in economics, mathematics, and statistics.
                Proven track record in quantitative finance through comprehensive projects in VaR modeling, portfolio
                optimization, and corporate valuation. Experienced teaching assistant with demonstrated leadership in
                student organizations. Passionate about applying mathematical and statistical methods to solve complex
                economic and financial problems.
              </p>
            </section>

            {/* Education */}
            <section>
              <h2 className="text-2xl font-bold mb-4 text-gray-800 border-b-2 border-purple-600 pb-2">Education</h2>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="text-lg font-semibold">Honours Bachelor of Science</h3>
                      <p className="text-gray-600">University of Toronto</p>
                      <p className="text-gray-600">Majors: Mathematics, Economics; Minor: Statistics</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">Sep 2021 - Jun 2026</p>
                      <p className="text-gray-600">Arts and Science Internship Program (Co-op)</p>
                    </div>
                  </div>
                  <p className="text-gray-700 text-sm mt-1">
                    <strong>Relevant Coursework:</strong> Financial Economics, Risk Management, Mathematics of Finance,
                    Econometrics, Optimization, Calculus, Differential Equations, Regression Analysis, Advanced
                    Microeconomics: Game Theory, Advanced Macroeconomics, Abstract Mathematics, Linear Algebra, Groups
                    and Symmetries
                  </p>
                </div>
              </div>
            </section>

            {/* Professional Experience */}
            <section>
              <h2 className="text-2xl font-bold mb-4 text-gray-800 border-b-2 border-purple-600 pb-2">
                Professional Experience
              </h2>
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="text-lg font-semibold">Teaching Assistant</h3>
                      <p className="text-gray-600">
                        University of Toronto - Financial Economics, Multivariable Calculus
                      </p>
                    </div>
                    <p className="font-medium">Sep 2024 - Apr 2025</p>
                  </div>
                  <ul className="text-gray-700 text-sm space-y-1 ml-4">
                    <li>
                      • Led weekly interactive tutorials for 80+ undergraduates with 15% average improvement in test
                      scores
                    </li>
                    <li>
                      • Designed supplementary review materials on LaTeX contributing to 70% reduction in additional
                      practice needs
                    </li>
                    <li>
                      • Coordinated with 15+ teaching assistants to grade 1,000+ test papers, reducing error rates by
                      25%
                    </li>
                  </ul>
                </div>

                <div>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="text-lg font-semibold">Learning Assistant (Mathematics)</h3>
                      <p className="text-gray-600">Kumon North America Inc.</p>
                    </div>
                    <p className="font-medium">Dec 2022 - Jun 2024</p>
                  </div>
                  <ul className="text-gray-700 text-sm space-y-1 ml-4">
                    <li>
                      • Facilitated tailored learning experience for 100+ students, improving calculation speeds and
                      test scores
                    </li>
                    <li>• Streamlined administrative processes saving 1 hour during operations</li>
                    <li>• Achieved 10% increase in monthly enrollment rates through effective parent communication</li>
                  </ul>
                </div>

                <div>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="text-lg font-semibold">Chief Returning Officer (CRO)</h3>
                      <p className="text-gray-600">Victoria University Students' Administrative Council (VUSAC)</p>
                    </div>
                    <p className="font-medium">May 2023 - Apr 2024</p>
                  </div>
                  <ul className="text-gray-700 text-sm space-y-1 ml-4">
                    <li>• Spearheaded Elections Code audits achieving 100% approval of amendments</li>
                    <li>• Co-developed VUSAC's first online election portal revolutionizing century-old processes</li>
                    <li>• Managed 2 election cycles with 3,500+ electors and record-breaking 15+ candidates</li>
                  </ul>
                </div>
              </div>
            </section>

            {/* Projects */}
            <section>
              <h2 className="text-2xl font-bold mb-4 text-gray-800 border-b-2 border-purple-600 pb-2">
                Featured Projects
              </h2>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-semibold">
                      From Data to VaR: A Simulation Based Approach to Portfolio Risk
                    </h3>
                    <p className="font-medium">Dec 2024</p>
                  </div>
                  <ul className="text-gray-700 text-sm space-y-1 ml-4">
                    <li>
                      • Developed Monte Carlo VaR model for $11.9B portfolio with 99% VaR and 95% historical accuracy
                    </li>
                    <li>• Leveraged Cholesky decomposition in STATA cutting simulation time by 70%</li>
                    <li>• Automated VaR simulation enabling 10,000 daily recalculations in under 2 minutes</li>
                  </ul>
                </div>

                <div>
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-semibold">Risk and Reward: CAPM Driven Portfolio Optimization</h3>
                    <p className="font-medium">Mar 2024</p>
                  </div>
                  <ul className="text-gray-700 text-sm space-y-1 ml-4">
                    <li>
                      • Analyzed 36 years of financial data achieving 17.10% expected return with 20.74% volatility
                    </li>
                    <li>• Implemented Excel Solver for tangent portfolio with Sharpe Ratio of 0.61 and beta of 0.39</li>
                    <li>• Created 6-visual Tableau dashboard for portfolio analysis and visualization</li>
                  </ul>
                </div>

                <div>
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-semibold">Navigating the Skies: A Valuation of Boeing Co.</h3>
                    <p className="font-medium">Feb 2024</p>
                  </div>
                  <ul className="text-gray-700 text-sm space-y-1 ml-4">
                    <li>• Executed comprehensive valuation using DDM, DCF, and Comparable Firm Analysis</li>
                    <li>• Automated data extraction with Excel macros reducing reporting time by 30%</li>
                    <li>• Designed Tableau visualizations increasing report generation efficiency by 40%</li>
                  </ul>
                </div>
              </div>
            </section>

            {/* Technical Skills */}
            <section>
              <h2 className="text-2xl font-bold mb-4 text-gray-800 border-b-2 border-purple-600 pb-2">
                Technical Skills
              </h2>
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div>
                  <h4 className="font-semibold mb-2">Programming & Software</h4>
                  <p className="text-gray-700">
                    Excel (Advanced VBA), STATA, Python, SQL, Bloomberg Terminal, Tableau, Power BI
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Financial Analysis</h4>
                  <p className="text-gray-700">
                    Monte Carlo Simulation, VaR Analysis, Financial Modeling, Risk Analysis, Portfolio Optimization
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Mathematical Methods</h4>
                  <p className="text-gray-700">Econometrics, Optimization, Regression Analysis, Statistical Modeling</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Trading & Markets</h4>
                  <p className="text-gray-700">
                    Capital Markets, Derivatives Pricing, Hedging Strategies, Asset Allocation
                  </p>
                </div>
              </div>
            </section>

            {/* Leadership & Activities */}
            <section>
              <h2 className="text-2xl font-bold mb-4 text-gray-800 border-b-2 border-purple-600 pb-2">
                Leadership & Activities
              </h2>
              <div className="space-y-3 text-sm">
                <div>
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-semibold">Hindustani Classical Vocals</h4>
                      <p className="text-gray-600">Shankar Mahadevan Academy - 6+ Years Training</p>
                    </div>
                    <p className="font-medium">2018 - Present</p>
                  </div>
                  <p className="text-gray-700 mt-1">
                    Advanced training in Indian classical music with focus on mathematical patterns in ragas and talas
                  </p>
                </div>
                <div>
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-semibold">Chapter Co-Founder</h4>
                      <p className="text-gray-600">The Period Society JIRS</p>
                    </div>
                    <p className="font-medium">Sep 2020 - May 2021</p>
                  </div>
                  <p className="text-gray-700 mt-1">
                    Pioneered menstrual equity advocacy providing opportunities for 25+ students and donating 200
                    sanitary pads
                  </p>
                </div>
              </div>
            </section>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
