"use client"

import type React from "react"

import { motion, useScroll, useTransform, useSpring, useMotionValue } from "framer-motion"
import { ArrowDown, Linkedin, Mail, Youtube, Facebook } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import Navigation from "@/components/navigation"
import ProjectSlider from "@/components/project-slider"
import EducationTimeline from "@/components/education-timeline"
import ContactForm from "@/components/contact-form"
import { useEffect, useState, useRef } from "react"
import MusicPlayer from "@/components/music-player"

// Floating particles component
const FloatingParticles = () => {
  const particles = Array.from({ length: 50 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 4 + 1,
    duration: Math.random() * 20 + 10,
  }))

  return (
    <div className="fixed inset-0 pointer-events-none z-0">
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          className="absolute bg-purple-500/20 rounded-full"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            width: particle.size,
            height: particle.size,
          }}
          animate={{
            y: [0, -100, 0],
            x: [0, Math.random() * 100 - 50, 0],
            opacity: [0, 1, 0],
          }}
          transition={{
            duration: particle.duration,
            repeat: Number.POSITIVE_INFINITY,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  )
}

// Magnetic button component
const MagneticButton = ({ children, className, ...props }: any) => {
  const ref = useRef<HTMLDivElement>(null)
  const x = useMotionValue(0)
  const y = useMotionValue(0)
  const springX = useSpring(x, { stiffness: 300, damping: 30 })
  const springY = useSpring(y, { stiffness: 300, damping: 30 })

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!ref.current) return
    const rect = ref.current.getBoundingClientRect()
    const centerX = rect.left + rect.width / 2
    const centerY = rect.top + rect.height / 2
    const distanceX = e.clientX - centerX
    const distanceY = e.clientY - centerY

    x.set(distanceX * 0.3)
    y.set(distanceY * 0.3)
  }

  const handleMouseLeave = () => {
    x.set(0)
    y.set(0)
  }

  return (
    <motion.div
      ref={ref}
      style={{ x: springX, y: springY }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={className}
      {...props}
    >
      {children}
    </motion.div>
  )
}

export default function Home() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const { scrollYProgress } = useScroll()
  const heroRef = useRef<HTMLElement>(null)

  // Parallax transforms
  const yBg = useTransform(scrollYProgress, [0, 1], ["0%", "50%"])
  const yText = useTransform(scrollYProgress, [0, 1], ["0%", "200%"])
  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 0.8])
  const opacity = useTransform(scrollYProgress, [0, 0.3], [1, 0])

  useEffect(() => {
    const updateMousePosition = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }
    window.addEventListener("mousemove", updateMousePosition)
    return () => window.removeEventListener("mousemove", updateMousePosition)
  }, [])

  const featuredPerformances = [
    {
      id: 1,
      title: "Bol Do Na Zara (Cover)",
      platform: "YouTube",
      link: "https://www.youtube.com/watch?v=BQp9d7LHMO8&list=WL&index=1",
      icon: Youtube,
      description: "My rendition of 'Bol Do Na Zara', originally sung by Armaan Malik and composed by Amaal Malik.",
    },
    {
      id: 2,
      title: "Friendship Medley (Group Performance)",
      platform: "YouTube",
      link: "https://www.youtube.com/watch?v=HaiY5xhMmfI&list=WL&index=8",
      icon: Youtube,
      description: "A group performance dedicated to graduating high school friends, featuring songs on friendship.",
    },
    {
      id: 3,
      title: "Shankar Mahadevan Academy Global Meet",
      platform: "Facebook",
      link: "https://www.facebook.com/shankarlive/videos/387615863329802/",
      icon: Facebook,
      description:
        "A group performance at the Shankar Mahadevan Academy's global online meet, in front of Shankar Mahadevan himself. My performance starts at 1:47:28.",
    },
  ]

  // Advanced animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.9 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 10,
      },
    },
  }

  const textVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
  }

  const titleVariants = {
    hidden: { opacity: 0, y: 50, scale: 0.9 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut",
        type: "spring",
        stiffness: 100,
      },
    },
  }

  const glowVariants = {
    initial: { boxShadow: "0 0 0 rgba(168, 85, 247, 0)" },
    hover: {
      boxShadow: "0 0 30px rgba(168, 85, 247, 0.5)",
      transition: { duration: 0.3 },
    },
  }

  return (
    <div className="min-h-screen bg-white dark:bg-black text-black dark:text-white overflow-x-hidden">
      {/* Floating Particles */}
      <FloatingParticles />

      {/* Enhanced animated background */}
      <motion.div className="fixed inset-0 z-0" style={{ y: yBg }}>
        <motion.div
          className="absolute w-96 h-96 bg-purple-500/10 rounded-full blur-3xl transition-all duration-1000 ease-out"
          animate={{
            x: mousePosition.x - 192,
            y: mousePosition.y - 192,
            scale: [1, 1.2, 1],
          }}
          transition={{
            x: { type: "spring", stiffness: 50, damping: 30 },
            y: { type: "spring", stiffness: 50, damping: 30 },
            scale: { duration: 4, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" },
          }}
        />
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-purple-900/10 via-transparent to-blue-900/10 dark:from-purple-900/20 dark:via-black dark:to-blue-900/20"
          animate={{
            background: [
              "radial-gradient(circle at 20% 50%, rgba(168, 85, 247, 0.1) 0%, transparent 50%)",
              "radial-gradient(circle at 80% 50%, rgba(59, 130, 246, 0.1) 0%, transparent 50%)",
              "radial-gradient(circle at 50% 20%, rgba(168, 85, 247, 0.1) 0%, transparent 50%)",
              "radial-gradient(circle at 20% 50%, rgba(168, 85, 247, 0.1) 0%, transparent 50%)",
            ],
          }}
          transition={{ duration: 10, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
        />
      </motion.div>

      <Navigation />

      {/* Hero Section with Parallax */}
      <motion.section
        ref={heroRef}
        id="home"
        className="relative z-10 min-h-screen flex items-center justify-center px-4"
        style={{ scale, opacity }}
      >
        <div className="max-w-6xl mx-auto text-center">
          <motion.div initial="hidden" animate="visible" variants={containerVariants}>
            <motion.h1
              className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-purple-700 to-blue-700 dark:from-white dark:via-purple-200 dark:to-blue-200 bg-clip-text text-transparent"
              variants={itemVariants}
              whileHover={{
                scale: 1.05,
                textShadow: "0 0 20px rgba(168, 85, 247, 0.5)",
              }}
            >
              Dhir Shah
            </motion.h1>
            <motion.p className="text-xl md:text-2xl text-secondary mb-8 font-light" variants={itemVariants}>
              Undergraduate Student at University of Toronto
            </motion.p>
          </motion.div>

          <motion.div
            className="flex flex-wrap justify-center gap-4 mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2, duration: 0.8 }}
          >
            <MagneticButton>
              <Button
                asChild
                className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-full transform transition-all duration-300 hover:scale-110 hover:shadow-2xl"
              >
                <Link href="#projects">View My Work</Link>
              </Button>
            </MagneticButton>
            <MagneticButton>
              <Button
                asChild
                variant="outline"
                className="border-gray-600 text-primary hover:bg-gray-800 px-8 py-3 rounded-full bg-transparent transform transition-all duration-300 hover:scale-110 hover:shadow-2xl"
              >
                <Link href="#contact">Get In Touch</Link>
              </Button>
            </MagneticButton>
          </motion.div>

          <motion.div
            animate={{
              y: [0, 10, 0],
              opacity: [0.5, 1, 0.5],
            }}
            transition={{
              duration: 2,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
            className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          >
            <ArrowDown className="w-6 h-6 text-muted" />
          </motion.div>
        </div>
      </motion.section>

      {/* About Section with Enhanced Animations */}
      <section id="about" className="relative z-10 py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: false, amount: 0.3 }}
            variants={titleVariants}
            className="text-center mb-16"
          >
            <motion.h2
              className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent"
              whileHover={{
                scale: 1.05,
                textShadow: "0 0 20px rgba(168, 85, 247, 0.5)",
              }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              About Me
            </motion.h2>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -100, rotateY: -30 }}
              whileInView={{ opacity: 1, x: 0, rotateY: 0 }}
              transition={{ duration: 1, ease: "easeOut" }}
              viewport={{ once: false, amount: 0.3 }}
            >
              <motion.div
                className="relative w-80 h-80 mx-auto bg-gradient-to-br from-purple-500 to-blue-500 rounded-full p-1"
                whileHover={{
                  rotateY: 15,
                  scale: 1.1,
                  boxShadow: "0 20px 40px rgba(168, 85, 247, 0.3)",
                }}
                transition={{ type: "spring", stiffness: 300, damping: 10 }}
                variants={glowVariants}
                initial="initial"
                whileHover="hover"
              >
                <motion.div
                  className="w-full h-full rounded-full overflow-hidden"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.3 }}
                >
                  <img
                    src="/images/dhir-profile.jpg"
                    alt="Dhir Shah - Professional headshot"
                    className="w-full h-full object-cover"
                  />
                </motion.div>
                {/* Animated border */}
                <motion.div
                  className="absolute inset-0 rounded-full border-2 border-purple-400"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                />
              </motion.div>
            </motion.div>

            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: false, amount: 0.5 }}
              variants={{
                visible: { transition: { staggerChildren: 0.15 } },
              }}
              className="space-y-6"
            >
              {[
                "Rationale — mom and dad's default option to push me to think beyond the box has become my mantra. My first practical classroom was a Boeing 777 from Nairobi to Ahmedabad — no syllabus, no grades, just lived experience. That early solo journey taught me that borders aren't just lines; they're ideas.",
                "Since then, I've been chasing the intersections — of economics and human behavior, numbers and narratives, policy and people.",
                "Today, I am an Economics and Mathematics student, using financial risk models, and game theory to decode the patterns behind decision-making — not just in markets, but everywhere. From reducing grading errors with data systems to reshaping student elections with digital tools, I believe that thoughtful design and relentless curiosity can make systems smarter and lives simpler.",
                "Tomorrow, I'm headed toward a Ph.D. in Financial Econometrics — not to live in an ivory tower, but to build bridges between theory and action, analysis and impact.",
                "I don't just want to understand the world — I want to optimize it. I believe education isn't a destination — it's a direction. And mine points to where data, empathy, and innovation meet.",
              ].map((text, index) => (
                <motion.p
                  key={index}
                  variants={{
                    hidden: { opacity: 0, scale: 0.98 },
                    visible: {
                      opacity: 1,
                      scale: 1,
                      transition: { duration: 0.6, ease: "easeOut" },
                    },
                  }}
                  className="text-lg text-secondary leading-relaxed"
                  whileHover={{ scale: 1.01, transition: { duration: 0.2 } }}
                >
                  {text}
                </motion.p>
              ))}

              <motion.div variants={textVariants} className="flex space-x-4 pt-4">
                <MagneticButton>
                  <Button
                    asChild
                    variant="ghost"
                    size="icon"
                    className="text-muted hover:text-primary transform transition-all duration-300 hover:scale-125"
                  >
                    <Link href="https://ca.linkedin.com/in/itisdhir" target="_blank">
                      <Linkedin className="w-6 h-6" />
                    </Link>
                  </Button>
                </MagneticButton>
                <MagneticButton>
                  <Button
                    asChild
                    variant="ghost"
                    size="icon"
                    className="text-muted hover:text-primary transform transition-all duration-300 hover:scale-125"
                  >
                    <Link href="mailto:dhir.shah@mail.utoronto.ca">
                      <Mail className="w-6 h-6" />
                    </Link>
                  </Button>
                </MagneticButton>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="relative z-10 py-20 px-4 bg-section-enhanced">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: false, amount: 0.3 }}
            variants={titleVariants}
            className="text-center mb-16"
          >
            <motion.h2
              className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent"
              whileHover={{
                scale: 1.05,
                backgroundImage: "linear-gradient(45deg, #8b5cf6, #3b82f6, #8b5cf6)",
              }}
              transition={{ duration: 0.3 }}
            >
              Education
            </motion.h2>
          </motion.div>
          <EducationTimeline />
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="relative z-10 py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: false, amount: 0.3 }}
            variants={titleVariants}
            className="text-center mb-16"
          >
            <motion.h2
              className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent"
              whileHover={{ scale: 1.05 }}
            >
              Featured Projects
            </motion.h2>
            <motion.p
              className="text-xl text-muted max-w-3xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              viewport={{ once: false, amount: 0.5 }}
            >
              A showcase of my quantitative finance and economics research projects, demonstrating practical
              applications of financial theory and mathematical modeling.
            </motion.p>
          </motion.div>
          <ProjectSlider />
        </div>
      </section>

      {/* Research Interests - Clean Redesign */}
      <section id="research" className="relative z-10 py-20 px-4 bg-section-enhanced">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: false, amount: 0.3 }}
            variants={titleVariants}
            className="text-center mb-16"
          >
            <motion.h2
              className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent"
              whileHover={{ scale: 1.05 }}
            >
              Research Interests
            </motion.h2>
            <motion.p
              className="text-xl text-muted max-w-4xl mx-auto leading-relaxed"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              viewport={{ once: false, amount: 0.5 }}
            >
              As I pursue higher education, I would like to explore the convergence of quantitative methods, financial
              theory, and mathematical patterns — including those found in Hindustani classical music — to develop
              innovative approaches to economic modelling and optimization.
            </motion.p>
          </motion.div>

          {/* Core Research Areas */}
          <motion.div
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: false, amount: 0.2 }}
            variants={{
              visible: { transition: { staggerChildren: 0.1 } },
            }}
          >
            {[
              {
                title: "Financial Econometrics",
                icon: "📈",
                description:
                  "Developing advanced statistical models for financial time series analysis, volatility forecasting, and risk assessment using econometric techniques.",
                applications: ["GARCH Models", "Time Series Analysis", "Volatility Modeling", "Market Risk Assessment"],
                color: "from-blue-500 to-cyan-500",
              },
              {
                title: "Quantitative Finance",
                icon: "💹",
                description:
                  "Mathematical modeling of financial instruments, derivatives pricing, and portfolio optimization using stochastic calculus and numerical methods.",
                applications: ["Derivatives Pricing", "Portfolio Theory", "Risk Management", "Monte Carlo Methods"],
                color: "from-green-500 to-emerald-500",
              },
              {
                title: "Mathematical Optimization",
                icon: "⚡",
                description:
                  "Applying linear and nonlinear programming, convex optimization, and algorithmic techniques to solve complex economic and financial problems.",
                applications: ["Linear Programming", "Convex Optimization", "Algorithm Design", "Resource Allocation"],
                color: "from-purple-500 to-violet-500",
              },
              {
                title: "Pure Mathematics",
                icon: "🔢",
                description:
                  "Exploring abstract mathematical concepts including analysis, algebra, and differential equations that underpin quantitative finance models.",
                applications: ["Real Analysis", "Abstract Algebra", "Differential Equations", "Measure Theory"],
                color: "from-orange-500 to-red-500",
              },
              {
                title: "Hindustani Music Theory",
                icon: "🎵",
                description:
                  "Investigating mathematical structures in Indian classical music, including raga theory, tala patterns, and their applications to algorithmic composition.",
                applications: ["Raga Mathematics", "Rhythmic Patterns", "Harmonic Analysis", "Algorithmic Composition"],
                color: "from-pink-500 to-rose-500",
              },
            ].map((area, index) => (
              <motion.div
                key={index}
                variants={{
                  hidden: { opacity: 0, y: 50, scale: 0.9 },
                  visible: {
                    opacity: 1,
                    y: 0,
                    scale: 1,
                    transition: {
                      duration: 0.8,
                      ease: "easeOut",
                      type: "spring",
                      stiffness: 100,
                    },
                  },
                }}
                whileHover={{
                  scale: 1.02,
                  y: -5,
                  boxShadow: "0 20px 40px rgba(168, 85, 247, 0.15)",
                }}
                className="bg-card-enhanced p-6 rounded-xl border border-gray-200 dark:border-gray-700 hover:border-purple-400 dark:hover:border-purple-500 transition-all duration-300"
              >
                <div className="flex items-center mb-4">
                  <motion.div
                    className={`w-12 h-12 rounded-full bg-gradient-to-r ${area.color} flex items-center justify-center text-white text-xl mr-4`}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    {area.icon}
                  </motion.div>
                  <h3 className="text-xl font-bold text-primary">{area.title}</h3>
                </div>

                <p className="text-secondary leading-relaxed mb-4 text-sm">{area.description}</p>

                <div className="space-y-2">
                  <h4 className="text-sm font-semibold text-primary">Key Areas:</h4>
                  <div className="flex flex-wrap gap-2">
                    {area.applications.map((app, i) => (
                      <span
                        key={i}
                        className="bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 px-2 py-1 rounded-md text-xs"
                      >
                        {app}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Research Intersections */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: false, amount: 0.3 }}
            variants={titleVariants}
            className="mb-12"
          >
            <h3 className="text-3xl font-bold text-center mb-8 text-primary pt-16">Research Intersections</h3>
            <p className="text-center text-secondary max-w-3xl mx-auto mb-12">
              The most innovative insights emerge where these disciplines converge, creating new methodologies and
              perspectives.
            </p>
          </motion.div>

          <motion.div
            className="grid md:grid-cols-2 gap-8"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: false, amount: 0.2 }}
            variants={{
              visible: { transition: { staggerChildren: 0.2 } },
            }}
          >
            <motion.div
              variants={{
                hidden: { opacity: 0, x: -50 },
                visible: {
                  opacity: 1,
                  x: 0,
                  transition: { duration: 0.8, ease: "easeOut" },
                },
              }}
              className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 p-8 rounded-2xl border border-blue-200 dark:border-blue-800"
              whileHover={{ scale: 1.02 }}
            >
              <div className="flex items-center mb-6">
                <div className="flex -space-x-2 mr-4">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center text-white text-sm">
                    📈
                  </div>
                  <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-violet-500 rounded-full flex items-center justify-center text-white text-sm">
                    ⚡
                  </div>
                </div>
                <h4 className="text-xl font-bold text-primary">Econometric Optimization</h4>
              </div>
              <p className="text-secondary leading-relaxed mb-4">
                Combining econometric modeling with optimization techniques to develop more efficient algorithms for
                parameter estimation and model selection in financial time series.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 px-3 py-1 rounded-full text-sm">
                  Parameter Estimation
                </span>
                <span className="bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 px-3 py-1 rounded-full text-sm">
                  Model Selection
                </span>
              </div>
            </motion.div>

            <motion.div
              variants={{
                hidden: { opacity: 0, x: 50 },
                visible: {
                  opacity: 1,
                  x: 0,
                  transition: { duration: 0.8, ease: "easeOut" },
                },
              }}
              className="bg-gradient-to-br from-pink-50 to-orange-50 dark:from-pink-900/20 dark:to-orange-900/20 p-8 rounded-2xl border border-pink-200 dark:border-pink-800"
              whileHover={{ scale: 1.02 }}
            >
              <div className="flex items-center mb-6">
                <div className="flex -space-x-2 mr-4">
                  <div className="w-8 h-8 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full flex items-center justify-center text-white text-sm">
                    🎵
                  </div>
                  <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center text-white text-sm">
                    🔢
                  </div>
                </div>
                <h4 className="text-xl font-bold text-primary">Mathematical Music Analysis</h4>
              </div>
              <p className="text-secondary leading-relaxed mb-4">
                Applying mathematical analysis to understand the structural patterns in Hindustani ragas and exploring
                their potential applications in algorithmic trading and pattern recognition.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="bg-pink-100 dark:bg-pink-900/30 text-pink-700 dark:text-pink-300 px-3 py-1 rounded-full text-sm">
                  Pattern Recognition
                </span>
                <span className="bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300 px-3 py-1 rounded-full text-sm">
                  Algorithmic Trading
                </span>
              </div>
            </motion.div>

            <motion.div
              variants={{
                hidden: { opacity: 0, x: -50 },
                visible: {
                  opacity: 1,
                  x: 0,
                  transition: { duration: 0.8, ease: "easeOut" },
                },
              }}
              className="bg-gradient-to-br from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 p-8 rounded-2xl border border-green-200 dark:border-green-800"
              whileHover={{ scale: 1.02 }}
            >
              <div className="flex items-center mb-6">
                <div className="flex -space-x-2 mr-4">
                  <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center text-white text-sm">
                    💹
                  </div>
                  <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center text-white text-sm">
                    🔢
                  </div>
                </div>
                <h4 className="text-xl font-bold text-primary">Quantitative Mathematical Finance</h4>
              </div>
              <p className="text-secondary leading-relaxed mb-4">
                Developing rigorous mathematical foundations for quantitative finance models, focusing on stochastic
                processes and their applications to derivatives pricing and risk management.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 px-3 py-1 rounded-full text-sm">
                  Stochastic Processes
                </span>
                <span className="bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 px-3 py-1 rounded-full text-sm">
                  Risk Management
                </span>
              </div>
            </motion.div>

            <motion.div
              variants={{
                hidden: { opacity: 0, x: -50 },
                visible: {
                  opacity: 1,
                  x: 0,
                  transition: { duration: 0.8, ease: "easeOut" },
                },
              }}
              className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 p-8 rounded-2xl border border-purple-200 dark:border-purple-800"
              whileHover={{ scale: 1.02 }}
            >
              <div className="flex items-center mb-6">
                <div className="flex -space-x-2 mr-4">
                  <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-violet-500 rounded-full flex items-center justify-center text-white text-sm">
                    ⚡
                  </div>
                  <div className="w-8 h-8 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full flex items-center justify-center text-white text-sm">
                    🎵
                  </div>
                </div>
                <h4 className="text-xl font-bold text-primary">Optimization in Music Theory</h4>
              </div>
              <p className="text-secondary leading-relaxed mb-4">
                Exploring how optimization principles can be applied to understand the mathematical structures in
                classical music composition and improvisation techniques.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 px-3 py-1 rounded-full text-sm">
                  Harmonic Optimization
                </span>
                <span className="bg-pink-100 dark:bg-pink-900/30 text-pink-700 dark:text-pink-300 px-3 py-1 rounded-full text-sm">
                  Compositional Analysis
                </span>
              </div>
            </motion.div>
          </motion.div>

          {/* Research Vision */}
        </div>
      </section>

      {/* Music & Arts Section */}
      <section id="music" className="relative z-10 py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: false, amount: 0.3 }}
            variants={titleVariants}
            className="text-center mb-16"
          >
            <motion.h2
              className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent"
              whileHover={{ scale: 1.05 }}
            >
              Musical Journey
            </motion.h2>
            <motion.p
              className="text-xl text-muted max-w-3xl mx-auto"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              viewport={{ once: false, amount: 0.5 }}
            >
              Beyond technology, I find deep fulfillment in the ancient art of Hindustani classical music, where
              mathematics meets melody.
            </motion.p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <motion.div
              initial={{ opacity: 0, x: -50, scale: 0.8 }}
              whileInView={{ opacity: 1, x: 0, scale: 1 }}
              transition={{ duration: 0.8, type: "spring", stiffness: 100 }}
              viewport={{ once: false, amount: 0.3 }}
              className="space-y-6"
            >
              <div className="relative">
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-orange-500/20 to-red-500/20 rounded-2xl blur-xl"
                  animate={{
                    scale: [1, 1.1, 1],
                    opacity: [0.5, 0.8, 0.5],
                  }}
                  transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
                />
                <motion.div
                  className="relative bg-gradient-to-br from-orange-100 to-red-100 dark:from-orange-900/30 dark:to-red-900/30 p-8 rounded-2xl border border-orange-200 dark:border-orange-800"
                  whileHover={{
                    scale: 1.02,
                    rotate: 1,
                    boxShadow: "0 20px 40px rgba(251, 146, 60, 0.3)",
                  }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <motion.div
                    className="text-6xl mb-4 text-center"
                    animate={{ rotate: [0, 5, -5, 0] }}
                    transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
                  >
                    🎵
                  </motion.div>
                  <h3 className="text-2xl font-bold mb-4 text-primary text-center">Hindustani Classical Vocal</h3>
                  <p className="text-secondary leading-relaxed text-center">
                    Training in the rich tradition of Indian classical music for over 6 years, exploring the intricate
                    relationship between mathematical patterns and melodic structures.
                  </p>
                </motion.div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: false, amount: 0.3 }}
              className="space-y-6"
            >
              <motion.div
                className="bg-gray-100/50 dark:bg-gray-800/50 backdrop-blur-sm p-6 rounded-xl border border-gray-200 dark:border-gray-700"
                whileHover={{
                  scale: 1.02,
                  boxShadow: "0 10px 30px rgba(0, 0, 0, 0.1)",
                }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <h4 className="text-lg font-semibold mb-4 text-primary flex items-center">
                  <motion.span className="text-2xl mr-3" whileHover={{ scale: 1.3, rotate: 15 }}>
                    🎼
                  </motion.span>
                  Musical Training
                </h4>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted">Academy</span>
                    <span className="text-primary font-medium">Shankar Mahadevan Academy</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted">Guru</span>
                    <span className="text-primary font-medium">Renuka Deshpande</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted">Years of Training</span>
                    <span className="text-primary font-medium">6+ Years</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted">Specialization</span>
                    <span className="text-primary font-medium">Hindustani Vocals</span>
                  </div>
                </div>
              </motion.div>

              <motion.div
                className="bg-gray-100/50 dark:bg-gray-800/50 backdrop-blur-sm p-6 rounded-xl border border-gray-200 dark:border-gray-700"
                whileHover={{
                  scale: 1.02,
                  boxShadow: "0 10px 30px rgba(0, 0, 0, 0.1)",
                }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <h4 className="text-lg font-semibold mb-4 text-primary flex items-center">
                  <motion.span className="text-2xl mr-3" whileHover={{ scale: 1.3, rotate: 15 }}>
                    🏆
                  </motion.span>
                  Achievements
                </h4>
                <ul className="space-y-2 text-sm">
                  {[
                    "Featured Performer: Sangam 2021",
                    "SA Level Examination Completer: Honours",
                    "RE Level Examination Candidate",
                  ].map((achievement, index) => (
                    <motion.li
                      key={index}
                      className="text-secondary flex items-center"
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1, duration: 0.5 }}
                      viewport={{ once: false, amount: 0.5 }}
                    >
                      <motion.span
                        className="w-1.5 h-1.5 bg-orange-400 rounded-full mr-3"
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, delay: index * 0.2 }}
                      />
                      {achievement}
                    </motion.li>
                  ))}
                </ul>
              </motion.div>
            </motion.div>
          </div>

          {/* Featured Performances with Staggered Animation */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: false, amount: 0.2 }}
            variants={{
              visible: { transition: { staggerChildren: 0.1 } },
            }}
            className="mb-16"
          >
            <h3 className="text-2xl font-bold mb-8 text-primary text-center">Featured Performances</h3>
            <p className="text-secondary max-w-3xl mx-auto text-center mb-8">
              Explore some of my live performances and recordings shared on social media and YouTube.
            </p>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredPerformances.map((performance, index) => (
                <motion.div
                  key={performance.id}
                  variants={{
                    hidden: { opacity: 0, y: 50, rotateX: -20 },
                    visible: {
                      opacity: 1,
                      y: 0,
                      rotateX: 0,
                      transition: { duration: 0.6, ease: "easeOut" },
                    },
                  }}
                  whileHover={{
                    scale: 1.05,
                    rotateY: 5,
                    boxShadow: "0 20px 40px rgba(168, 85, 247, 0.2)",
                  }}
                  className="bg-card-enhanced p-6 rounded-xl border border-gray-200 dark:border-gray-700 hover:border-purple-500 transition-all duration-300 flex flex-col items-center text-center transform-gpu"
                >
                  <motion.div
                    className="text-5xl mb-4 text-purple-600 dark:text-purple-400"
                    whileHover={{ scale: 1.2, rotate: 10 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <performance.icon className="w-12 h-12 mx-auto" />
                  </motion.div>
                  <h4 className="font-bold text-lg text-primary mb-2">{performance.title}</h4>
                  <p className="text-sm text-muted mb-4">{performance.description}</p>
                  <MagneticButton className="mt-auto">
                    <Button
                      asChild
                      className="bg-purple-600 hover:bg-purple-700 text-white transform transition-all duration-300 hover:scale-105"
                    >
                      <Link href={performance.link} target="_blank" rel="noopener noreferrer">
                        Watch on {performance.platform}
                      </Link>
                    </Button>
                  </MagneticButton>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Ragas with Wave Animation */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: false, amount: 0.3 }}
            className="mb-16"
          >
            <h3 className="text-2xl font-bold mb-8 text-primary text-center">Ragas in My Repertoire</h3>
            <motion.div
              className="grid md:grid-cols-3 lg:grid-cols-4 gap-4"
              initial="hidden"
              whileInView="visible"
              viewport={{ once: false, amount: 0.2 }}
              variants={{
                visible: { transition: { staggerChildren: 0.05 } },
              }}
            >
              {[
                { name: "Yaman", time: "रात्री का पहला प्रहर (First Quarter of the Night / Evening)", mood: "Romantic" },
                { name: "Bhairav", time: "उषा काल (At Dawn)", mood: "Devotional" },
                { name: "Durga", time: "रात्रि का दूसरा प्रहर (Second Quarter of the Night)", mood: "Love" },
                {
                  name: "Khamaj",
                  time: "रात्रि का दूसरा प्रहर (Second Quarter of the Night)",
                  mood: "Light and Enthralling but not Sedate",
                },
                {
                  name: "Bhupali",
                  time: "रात्री का पहला प्रहर (First Quarter of the Night / Evening)",
                  mood: "Peaceful",
                },
                { name: "Kafi", time: "रात्रि का दूसरा प्रहर (Second Quarter of the Night)", mood: "Folk-like" },
                { name: "Alhaiya Bilawal", time: "दिन का द्वितीय प्रहर (Second Quarter of the Day)", mood: "Bright" },
                { name: "Brindavani Sarang", time: "मध्याहंकाल (Early Afternoon)", mood: "Romantic" },
                { name: "Des", time: "रात का द्वितीय प्रहर (Second Quarter of the Night)", mood: "Devotional" },
              ].map((raga, index) => (
                <motion.div
                  key={index}
                  variants={{
                    hidden: { opacity: 0, scale: 0.8, y: 20 },
                    visible: {
                      opacity: 1,
                      scale: 1,
                      y: 0,
                      transition: { duration: 0.5, ease: "easeOut" },
                    },
                  }}
                  whileHover={{
                    scale: 1.05,
                    rotateY: 5,
                    boxShadow: "0 10px 20px rgba(251, 146, 60, 0.2)",
                  }}
                  className="bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-900/20 dark:to-red-900/20 p-4 rounded-lg border border-orange-200 dark:border-orange-800 hover:border-orange-400 dark:hover:border-orange-600 transition-all duration-300 transform-gpu"
                >
                  <h4 className="font-bold text-primary mb-2">{raga.name}</h4>
                  <p className="text-xs text-muted mb-1">
                    <span className="font-medium">Time:</span> {raga.time}
                  </p>
                  <p className="text-xs text-muted">
                    <span className="font-medium">Mood:</span> {raga.mood}
                  </p>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>

          {/* Music and Technology Connection */}
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            whileInView={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: false, amount: 0.3 }}
            whileHover={{ scale: 1.02 }}
            className="bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900/30 dark:to-blue-900/30 p-8 rounded-2xl border border-purple-200 dark:border-purple-800"
          >
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold mb-4 text-primary">Where Music Meets Economics & Mathematics</h3>
              <p className="text-secondary max-w-3xl mx-auto leading-relaxed">
                My passion for Hindustani classical music deeply influences my approach to economics and mathematical
                research. The mathematical precision required in ragas mirrors the analytical thinking in economic
                modeling, while the improvisational nature of classical music inspires creative problem-solving in
                quantitative analysis and financial research.
              </p>
            </div>

            <motion.div
              className="grid md:grid-cols-3 gap-6"
              initial="hidden"
              whileInView="visible"
              viewport={{ once: false, amount: 0.2 }}
              variants={{
                visible: { transition: { staggerChildren: 0.2 } },
              }}
            >
              {[
                {
                  icon: "🧮",
                  title: "Mathematical Patterns",
                  description:
                    "Understanding tala cycles and rhythmic patterns enhances my approach to economic modeling and statistical analysis",
                },
                {
                  icon: "🎨",
                  title: "Creative Expression",
                  description:
                    "Improvisation in ragas inspires innovative approaches to financial modeling and economic research",
                },
                {
                  icon: "🧘",
                  title: "Mindful Practice",
                  description:
                    "Daily riyaz (practice) cultivates discipline and focus essential for rigorous economic and mathematical research",
                },
              ].map((item, index) => (
                <motion.div
                  key={index}
                  className="text-center"
                  variants={{
                    hidden: { opacity: 0, y: 20 },
                    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
                  }}
                  whileHover={{ y: -5 }}
                >
                  <motion.div
                    className="text-3xl mb-3"
                    whileHover={{ scale: 1.2, rotate: 10 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    {item.icon}
                  </motion.div>
                  <h4 className="font-semibold mb-2 text-primary">{item.title}</h4>
                  <p className="text-sm text-muted">{item.description}</p>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>

          {/* Music Player */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: false, amount: 0.3 }}
            className="mt-16"
          >
            <MusicPlayer />
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="relative z-10 py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: false, amount: 0.3 }}
            variants={titleVariants}
            className="text-center mb-16"
          >
            <motion.h2
              className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent"
              whileHover={{ scale: 1.05 }}
            >
              Get In Touch
            </motion.h2>
            <motion.p
              className="text-xl text-muted max-w-2xl mx-auto"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              viewport={{ once: false, amount: 0.5 }}
            >
              I'm always open to discussing research opportunities, collaborations, or just having a casual
              conversation!
            </motion.p>
          </motion.div>
          <ContactForm />
        </div>
      </section>

      {/* Enhanced Footer */}
      <motion.footer
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: false, amount: 0.3 }}
        className="relative z-10 py-8 px-4 border-t border-gray-200 dark:border-gray-800"
      >
        <motion.div
          className="max-w-6xl mx-auto text-center"
          whileHover={{ scale: 1.02 }}
          transition={{ duration: 0.2 }}
        >
          <p className="text-muted">© {new Date().getFullYear()} Dhir Shah. All rights reserved.</p>
        </motion.div>
      </motion.footer>
    </div>
  )
}
