import type React from "react"
import type { Metadata } from "next"
import { Inter, JetBrains_Mono } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider" // Our custom ThemeProvider

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
})

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
})

export const metadata: Metadata = {
  title: "Dhir Shah - Academic Portfolio",
  description: "Undergraduate Student Pursuing Economics and Mathematics, with a Minor in Statistics",
  keywords: ["economics", "mathematics", "statistics", "undergraduate student", "University of Toronto"],
  authors: [{ name: "Dhir Shah" }],
  openGraph: {
    title: "Dhir Shah - Academic Portfolio",
    description: "Undergraduate Student Pursuing Economics and Mathematics, with a Minor in Statistics",
    type: "website",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} ${jetbrainsMono.variable} font-sans antialiased`}>
        {/* Use our custom ThemeProvider */}
        <ThemeProvider>{children}</ThemeProvider>
      </body>
    </html>
  )
}
