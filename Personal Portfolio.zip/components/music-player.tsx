"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { Play, Pause, Music } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { formatTime } from "@/utils/formatTime" // Import the utility function

interface MusicTrack {
  id: number
  title: string
  raga: string
  audioSrc: string // Added audio source path
  description: string
}

const musicTracks: MusicTrack[] = [
  {
    id: 1,
    title: "Lakshangeet",
    raga: "Yaman",
    audioSrc: "https://bzcxyaw1to70n5lp.public.blob.vercel-storage.com/Lakshangeet.m4a", // Updated path for the new audio file
    description: "My own composition in Raga Yaman.",
  },
  {
    id: 2,
    title: "Tirvat",
    raga: "Bhupali",
    audioSrc: "https://bzcxyaw1to70n5lp.public.blob.vercel-storage.com/Tirvat.m4a", // Updated path for the new audio file
    description: "A traditional Tirvat composition in Raga Bhupali.",
  },
  {
    id: 3,
    title: "Sakhi Mori Bandish",
    raga: "Durga",
    audioSrc: "https://bzcxyaw1to70n5lp.public.blob.vercel-storage.com/Sakhi%20Mori.m4a", // Updated path for the new audio file
    description: "A traditional bandish in Raga Durga, set to Jhaptaal.",
  },
]

export default function MusicPlayer() {
  const [currentTrackId, setCurrentTrackId] = useState<number | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  const currentTrack = musicTracks.find((track) => track.id === currentTrackId)

  // Effect for setting up audio event listeners and cleanup
  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const handleLoadedMetadata = () => {
      setDuration(audio.duration)
    }

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime)
    }

    const handleEnded = () => {
      setIsPlaying(false)
      setCurrentTime(0)
    }

    audio.addEventListener("loadedmetadata", handleLoadedMetadata)
    audio.addEventListener("timeupdate", handleTimeUpdate)
    audio.addEventListener("ended", handleEnded)

    return () => {
      audio.removeEventListener("loadedmetadata", handleLoadedMetadata)
      audio.removeEventListener("timeupdate", handleTimeUpdate)
      audio.removeEventListener("ended", handleEnded)
      // Pause and reset on unmount
      audio.pause()
      audio.currentTime = 0
    }
  }, []) // Empty dependency array: runs once on mount, cleans up on unmount

  // Effect for managing audio playback based on currentTrack and isPlaying state
  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    if (currentTrack) {
      // Only update src if it's different to avoid unnecessary reloads
      // window.location.origin is added to ensure full URL comparison for consistency
      if (audio.src !== window.location.origin + currentTrack.audioSrc) {
        audio.src = currentTrack.audioSrc
        audio.load() // Load the new source
      }

      if (isPlaying) {
        audio.play().catch((error) => {
          // Catch and log AbortError to prevent unhandled promise rejection
          if (error.name === "AbortError") {
            console.warn("Audio playback aborted (likely due to rapid changes or user interaction).", error)
          } else {
            console.error("Error playing audio:", error)
          }
        })
      } else {
        audio.pause()
      }
    } else {
      // No track selected, ensure audio is paused and reset
      audio.pause()
      audio.currentTime = 0
      setDuration(0)
      setCurrentTime(0)
    }
  }, [currentTrack, isPlaying]) // Dependencies: currentTrack (for src change) and isPlaying (for play/pause)

  const playTrack = (trackId: number) => {
    if (!audioRef.current) return

    if (currentTrackId === trackId) {
      // Toggle play/pause for the same track
      setIsPlaying(!isPlaying)
    } else {
      // New track selected
      setCurrentTrackId(trackId)
      setIsPlaying(true) // This will trigger the useEffect to load and play the new track
    }
  }

  const handleSliderChange = (value: number[]) => {
    if (audioRef.current) {
      audioRef.current.currentTime = value[0]
      setCurrentTime(value[0])
    }
  }

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="text-center mb-8"
      >
        <h3 className="text-2xl font-bold mb-4 text-primary">Musical Recordings</h3>
        <p className="text-secondary max-w-2xl mx-auto">
          Listen to some of my performances and practice sessions showcasing different ragas and compositions.
        </p>
      </motion.div>

      <audio ref={audioRef} preload="metadata" />

      <div className="grid gap-4">
        {musicTracks.map((track, index) => (
          <motion.div
            key={track.id}
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            viewport={{ once: true }}
            className={`bg-card-enhanced p-6 rounded-xl border transition-all duration-300 ${
              currentTrackId === track.id
                ? "border-orange-400 shadow-lg"
                : "border-gray-200 dark:border-gray-700 hover:border-orange-300 dark:hover:border-orange-600"
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  onClick={() => playTrack(track.id)}
                  size="icon"
                  className={`rounded-full ${
                    currentTrackId === track.id && isPlaying
                      ? "bg-orange-500 hover:bg-orange-600"
                      : "bg-gray-600 hover:bg-gray-700"
                  }`}
                  aria-label={currentTrackId === track.id && isPlaying ? "Pause" : "Play"}
                >
                  {currentTrackId === track.id && isPlaying ? (
                    <Pause className="w-4 h-4" />
                  ) : (
                    <Play className="w-4 h-4" />
                  )}
                </Button>

                <div className="flex-1">
                  <h4 className="font-semibold text-primary">{track.title}</h4>
                  <p className="text-sm text-secondary">Raga: {track.raga}</p>
                  <p className="text-xs text-muted mt-1">{track.description}</p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="icon" className="text-muted hover:text-primary" aria-label="Music icon">
                  <Music className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {currentTrackId === track.id && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                transition={{ duration: 0.3 }}
                className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700"
              >
                <div className="flex items-center space-x-4">
                  <span className="text-xs text-muted">{formatTime(currentTime)}</span>
                  <div className="flex-1">
                    <Slider
                      value={[currentTime]}
                      max={duration}
                      step={1}
                      className="w-full"
                      onValueChange={handleSliderChange}
                      aria-label="Audio progress slider"
                    />
                  </div>
                  <span className="text-xs text-muted">{formatTime(duration)}</span>
                </div>
              </motion.div>
            )}
          </motion.div>
        ))}
      </div>

      
    </div>
  )
}
