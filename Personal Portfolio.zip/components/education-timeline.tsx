"use client"

import { motion } from "framer-motion"
import { GraduationCap, BookOpen } from "lucide-react"

const educationData = [
  {
    id: 1,
    degree: "Honours Bachelor of Science (HBSc): Double Major in Economics and Mathematics; Minor in Statistics",
    institution: "University of Toronto",
    period: "September 2021 - May 2026",
    description:
      "Relevant Coursework: Financial Economics, Risk Management, Mathematics of Finance, Econometrics, Calculus, Differential Equations, Regression Analysis, Advanced Microeconomics: Game Theory, Advanced Macroeconomics, Abstract Mathematics, Linear Algebra, Groups and Symmetries, Optimization",
    achievements: [
      "Teaching Assistant within the Mathematics (MAT235Y1) and Economics (ECO358H1) Departments",
      "Active Member of the Victoria University Students' Administrative Council (VUSAC)",
    ],
    icon: GraduationCap,
  },
]

export default function EducationTimeline() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2, // Stagger delay for each timeline item
      },
    },
  }

  const itemVariants = (isEven: boolean) => ({
    hidden: { opacity: 0, x: isEven ? -100 : 100, scale: 0.9 },
    visible: {
      opacity: 1,
      x: 0,
      scale: 1,
      transition: {
        type: "spring",
        stiffness: 80,
        damping: 15,
        duration: 0.8,
      },
    },
  })

  const achievementVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: "easeOut" } },
  }

  return (
    <motion.div
      className="relative"
      initial="hidden"
      whileInView="visible"
      viewport={{ once: false, amount: 0.2 }} // Trigger animation when 20% of component is in view, every time
      variants={containerVariants}
    >
      {/* Timeline line */}
      <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-purple-500 to-blue-500 transform md:-translate-x-0.5" />

      <div className="space-y-12">
        {educationData.map((item, index) => {
          const isEven = index % 2 === 0
          return (
            <motion.div
              key={item.id}
              variants={itemVariants(isEven)}
              className={`relative flex items-center ${isEven ? "md:flex-row" : "md:flex-row-reverse"}`}
            >
              {/* Timeline dot */}
              <motion.div
                className="absolute left-4 md:left-1/2 w-4 h-4 bg-purple-500 rounded-full transform -translate-x-2 md:-translate-x-2 z-10 border-4 border-black"
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", delay: index * 0.2 }}
              />

              {/* Content */}
              <div className={`ml-12 md:ml-0 md:w-1/2 ${isEven ? "md:pr-12" : "md:pl-12"}`}>
                <motion.div
                  whileHover={{
                    scale: 1.02,
                    rotateY: isEven ? 5 : -5,
                    boxShadow: "0 20px 40px rgba(168, 85, 247, 0.2)",
                    borderColor: "rgba(168, 85, 247, 0.5)",
                  }}
                  transition={{ type: "spring", stiffness: 300, damping: 10 }}
                  className="bg-card-enhanced p-6 rounded-xl border border-gray-800 hover:border-purple-500 transition-all duration-300 transform-gpu"
                >
                  <div className="flex items-center mb-4">
                    <motion.div whileHover={{ scale: 1.3, rotate: 15 }} transition={{ type: "spring", stiffness: 300 }}>
                      <item.icon className="w-6 h-6 text-purple-400 mr-3" />
                    </motion.div>
                    <span className="text-purple-400 font-medium">{item.period}</span>
                  </div>

                  <h3 className="text-xl font-bold text-primary mb-2">{item.degree}</h3>
                  <h4 className="text-lg text-secondary mb-2">{item.institution}</h4>
                  {item.gpa && <p className="text-purple-300 font-medium mb-4">Score: {item.gpa}</p>}

                  <p className="text-muted mb-4 leading-relaxed whitespace-pre-line">{item.description}</p>

                  <div className="space-y-2">
                    <h5 className="text-primary font-medium flex items-center">
                      <BookOpen className="w-4 h-4 mr-2 text-purple-400" />
                      Key Achievements:
                    </h5>
                    <motion.ul
                      className="space-y-1"
                      initial="hidden"
                      whileInView="visible" // Animate achievements when parent is visible
                      viewport={{ once: false, amount: 0.5 }}
                      variants={{
                        visible: { transition: { staggerChildren: 0.1 } },
                      }}
                    >
                      {item.achievements.map((achievement, i) => (
                        <motion.li
                          key={i}
                          variants={achievementVariants}
                          className="text-muted text-sm flex items-center"
                        >
                          <span className="w-1.5 h-1.5 bg-purple-400 rounded-full mr-2" />
                          {achievement}
                        </motion.li>
                      ))}
                    </motion.ul>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          )
        })}
      </div>
    </motion.div>
  )
}
