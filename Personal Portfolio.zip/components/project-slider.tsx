"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react" // Added useRef
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const projects = [
  {
    id: 1,
    title: "From Data to VaR: A Simulation Based Approach to Portfolio Risk",
    description:
      "Consolidated 2 years of market data from Google Finance to compute daily drift and volatility, and ran 10-day price evolutions, delivering a 99% VaR with 95% historical accuracy. Developed a 10-day Monte Carlo VaR model for a $11.9 billion, 7-stock portfolio in Excel, leveraging Cholesky decomposition in STATA, cutting simulation time by 70%. Automated multi-step VaR simulation using correlated random draws and What-if Analysis in Excel, enabling 10,000 daily recalculations in under 2 minutes.",
    image: "/images/data-to-var.png", // Updated image path
    technologies: [
      "Excel",
      "STATA",
      "Monte Carlo Simulation",
      "Cholesky Decomposition",
      "VaR Modeling",
      "Financial Data Analysis",
    ],
    demo: "https://drive.google.com/drive/folders/1jK68EkIpwD47RelrAjC2TXFrg_sl4Mte?usp=sharing",
    category: "Quantitative Finance",
  },
  {
    id: 2,
    title: "Risk and Reward: CAPM Driven Portfolio Optimization",
    description:
      "Analyzed stock covariance in STATA to validate diversification and demonstrate portfolio optimization theories. Constructed a CAPM-driven portfolio using 36 years of historical data in Excel with 17.10% expected return and 20.74% volatility, effectively balancing investment risk and return. Leveraged Excel's Solver to identify the tangent portfolio on the efficient frontier. Produced a comprehensive 6-visual Tableau dashboard for improved data visualization and analytical clarity.",
    image: "/images/risk-and-reward.png", // Updated image path
    technologies: [
      "Excel",
      "STATA",
      "Tableau",
      "CAPM Modeling",
      "Portfolio Optimization",
      "Covariance Analysis",
      "Solver",
    ],
    demo: "#", // No link available yet
    category: "Portfolio Management",
  },
  {
    id: 3,
    title: "Navigating the Skies: A Valuation of Boeing Co.",
    description:
      "Automated data extraction via Excel macros to cut financial reporting time by 30%. Executed a comprehensive valuation framework of Boeing using multiple methodologies including Dividend Discount Model (DDM), Discounted Cash Flow (DCF), and Comparable Firm analysis, revealing significant valuation discrepancies and enhancing strategic financial decision-making. Designed interactive Tableau visualizations comparing valuations of Boeing, Airbus, and Lockheed Martin, raising analytical efficiency by 40%.",
    image: "/images/boeing-valuation.png", // Updated image path
    technologies: [
      "Excel Macros",
      "DCF Modeling",
      "DDM Analysis",
      "Comparable Analysis",
      "Tableau",
      "Financial Modeling",
      "VBA",
    ],
    demo: "https://drive.google.com/drive/folders/1wX3YWlmKIZ9yLhWs6pcw-YT7zYgDZqVE?usp=drive_link",
    category: "Corporate Finance",
  },
  {
    id: 4,
    title: "Historical Essay: National Pride or Rigor? The Calculus Pamphlet War",
    description:
      "In this essay, I argue that the calculus pamphlet war, was primarily driven by national pride and personal antagonism rather than dispassionate mathematics. England and Continental Europe — particularly France — took up the dispute with pamphlets, letters, and institutional endorsements, turning it into a compelling symbol of political and cultural competition. While I draw on J. B. Shank’s analysis of French intellectual shifts, I extend his account by showing how pamphlet circulation heightened the drama and attracted new participants from beyond the established scientific communities.",
    image: "/images/calculus-essay.png", // Updated image path
    technologies: ["Historical Research", "Academic Writing", "History of Mathematics", "Calculus", "Communication"],
    demo: "https://www.overleaf.com/read/kgxcxpxzydff#426ea2",
    category: "Academic Research",
  },
]

export default function ProjectSlider() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const touchStartX = useRef(0)
  const touchEndX = useRef(0)
  const minSwipeDistance = 50 // Minimum pixels for a swipe to be registered

  const nextProject = () => {
    setCurrentIndex((prev) => (prev + 1) % projects.length)
  }

  const prevProject = () => {
    setCurrentIndex((prev) => (prev - 1 + projects.length) % projects.length)
  }

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "ArrowLeft") {
        prevProject()
      } else if (event.key === "ArrowRight") {
        nextProject()
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => {
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [currentIndex]) // Re-run effect if currentIndex changes to ensure correct closure

  // Touch swipe handlers
  const onTouchStart = (e: React.TouchEvent) => {
    touchEndX.current = 0 // Reset touchEndX on new touch start
    touchStartX.current = e.targetTouches[0].clientX
  }

  const onTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX
  }

  const onTouchEnd = () => {
    if (!touchStartX.current || !touchEndX.current) return

    const distance = touchStartX.current - touchEndX.current
    const isLeftSwipe = distance > minSwipeDistance
    const isRightSwipe = distance < -minSwipeDistance

    if (isLeftSwipe) {
      nextProject()
    } else if (isRightSwipe) {
      prevProject()
    }
  }

  return (
    <div className="relative">
      <div
        className="overflow-hidden rounded-2xl"
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, x: 300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -300 }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-2xl overflow-hidden"
          >
            <div className="grid md:grid-cols-2 gap-0">
              <div className="relative h-64 md:h-96">
                <div
                  className="absolute inset-0 bg-gradient-to-br from-purple-500/20 to-blue-500/20"
                  style={{
                    backgroundImage: `url(${projects[currentIndex].image})`,
                    backgroundSize: "cover",
                    backgroundPosition: "center",
                  }}
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-purple-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {projects[currentIndex].category}
                  </span>
                </div>
              </div>

              <div className="p-8 flex flex-col justify-center">
                <h3 className="text-2xl md:text-3xl font-bold mb-4 text-white">{projects[currentIndex].title}</h3>
                <p className="text-gray-300 mb-6 leading-relaxed">{projects[currentIndex].description}</p>

                <div className="flex flex-wrap gap-2 mb-6">
                  {projects[currentIndex].technologies.map((tech) => (
                    <span key={tech} className="bg-gray-700 text-gray-300 px-3 py-1 rounded-full text-sm">
                      {tech}
                    </span>
                  ))}
                </div>

                <div className="flex space-x-4">
                  <Button asChild className="bg-purple-600 hover:bg-purple-700 text-white">
                    <Link href={projects[currentIndex].demo} target="_blank">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      View Project
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation Controls */}
      <div className="flex items-center justify-between mt-8">
        <Button
          variant="ghost"
          size="icon"
          onClick={prevProject}
          className="text-secondary hover:bg-muted hover:text-primary rounded-full"
          aria-label="Previous project"
        >
          <ChevronLeft className="w-6 h-6" />
        </Button>

        <div className="flex space-x-2">
          {projects.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentIndex ? "bg-purple-500 scale-125" : "bg-gray-600 hover:bg-gray-500"
              }`}
              aria-label={`Go to project ${index + 1}`}
            />
          ))}
        </div>

        <Button
          variant="ghost"
          size="icon"
          onClick={nextProject}
          className="text-secondary hover:bg-muted hover:text-primary rounded-full"
          aria-label="Next project"
        >
          <ChevronRight className="w-6 h-6" />
        </Button>
      </div>
    </div>
  )
}
