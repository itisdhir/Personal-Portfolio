// This file is now a wrapper for our custom ThemeProvider from context/theme-context.tsx
"use client"

import type React from "react"

import { ThemeProvider as CustomThemeProvider } from "@/context/theme-context"

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  return <CustomThemeProvider>{children}</CustomThemeProvider>
}
